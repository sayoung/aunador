ABOUT AUNADOR
------------

AUNADOR is the default theme for Drupal 9.  It is a flexible, 
with a responsive and mobile-first layout, supporting  regions.



ABOUT DRUPAL THEMING
--------------------

See https://www.drupal.org/docs/8/theming for more information on Drupal
theming.
