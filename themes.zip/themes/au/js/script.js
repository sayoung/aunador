if(jQuery(window).width() > 719){ 
    var myFullpage = new fullpage('#fullpage', {
        sectionsColor: ['#1bbc9b', '#ebebeb', '#5e715b', '#def5f6', '#ccddff', '#53b9bf'],
        anchors: ['Accueil', 'Services', 'Actualités', 'Medias', 'Notre_territoire', 'Avis_et_annonces', 'Contact'],
        navigationTooltips: ['Accueil', 'Services', 'Actualités', 'Medias', 'Notre territoire', 'Avis et annonces', 'Contact'],
        showActiveTooltip: false,
        licenseKey: '2375FC98-5990473D-A3474621-FD11215A',
        menu: '#menu',
       navigation: true,
        //equivalent to jQuery `easeOutBack` extracted from http://matthewlein.com/ceaser/
        easingcss3: 'cubic-bezier(0.175, 0.885, 0.320, 1.275)',
	onLeave: function(origin, destination, direction){
		//it won't scroll if the destination is the 3rd section
		if(destination.index == 0){
			
			 jQuery('#header').removeClass( "hidewrapper" ); 
		} else  {
     
          jQuery('#header').addClass( "hidewrapper" );   

      }
	}
    });
     }
	 
	 
var $ = jQuery.noConflict();
$('#views-exposed-form-e-prestation-page-1 #edit-submit-e-prestation').on('click', function(e){
       e.preventDefault();

	   var commun = $('#views-exposed-form-e-prestation-page-1 #edit-field-avis-pref-target-id-shs-0-1').val();
	   var pref = $('#views-exposed-form-e-prestation-page-1 #edit-field-avis-pref-target-id-shs-0-0').val();
        if (commun == "All" ) {
           
             
           //   var element = document.getElementById("edit-field-avis-pref-target-id-shs-0-0"); 
              var element1 = document.getElementById("edit-field-avis-pref-target-id-shs-0-1");
              
 // element.classList.add("error");
  element1.classList.add("error");
          
     
}else if (pref == "All" ) {
           
             
              var element = document.getElementById("edit-field-avis-pref-target-id-shs-0-0"); 
           //   var element1 = document.getElementById("edit-field-avis-pref-target-id-shs-0-1");
              
  element.classList.add("error");
//  element1.classList.add("error");
          
     
} else {
          $('#views-exposed-form-e-prestation-page-1').submit();
       }
   
    })
    
$('#views-exposed-form-programmes-des-commissions-page-1 #edit-submit-programmes-des-commissions').on('click', function(e){
       e.preventDefault();
	   var commun = $('#views-exposed-form-programmes-des-commissions-page-1 #edit-field-avis-pref-target-id-shs-0-1').val();
	   var pref = $('#views-exposed-form-programmes-des-commissions-page-1 #edit-field-avis-pref-target-id-shs-0-0').val();
        if (commun == "All" ) {
              var element1 = document.getElementById("edit-field-avis-pref-target-id-shs-0-1");
  element1.classList.add("error");
}else if (pref == "All" ) {
              var element = document.getElementById("edit-field-avis-pref-target-id-shs-0-0"); 
  element.classList.add("error");
} else {
          $('#views-exposed-form-programmes-des-commissions-page-1').submit();
       }
    })
    
$('#views-exposed-form-programmes-des-commissions-page-2 #edit-submit-programmes-des-commissions').on('click', function(e){
       e.preventDefault();
	   var commun = $('#views-exposed-form-programmes-des-commissions-page-2 #edit-field-avis-pref-target-id-shs-0-1').val();
	   var pref = $('#views-exposed-form-programmes-des-commissions-page-2 #edit-field-avis-pref-target-id-shs-0-0').val();
        if (commun == "All" ) {
              var element1 = document.getElementById("edit-field-avis-pref-target-id-shs-0-1");
  element1.classList.add("error");
}else if (pref == "All" ) {
              var element = document.getElementById("edit-field-avis-pref-target-id-shs-0-0"); 
  element.classList.add("error");
} else {
          $('#views-exposed-form-programmes-des-commissions-page-2').submit();
       }
    })

$('#views-exposed-form-modifier-les-dossier-page-1 #edit-submit-modifier-les-dossier').on('click', function(e){
       e.preventDefault();
	   var commun = $('#views-exposed-form-modifier-les-dossier-page-1 #edit-field-avis-pref-target-id-shs-0-1').val();
	   var pref = $('#views-exposed-form-modifier-les-dossier-page-1 #edit-field-avis-pref-target-id-shs-0-0').val();
        if (commun == "All" ) {
              var element1 = document.getElementById("edit-field-avis-pref-target-id-shs-0-1");
  element1.classList.add("error");
}else if (pref == "All" ) {
              var element = document.getElementById("edit-field-avis-pref-target-id-shs-0-0"); 
  element.classList.add("error");
} else {
          $('#views-exposed-form-modifier-les-dossier-page-1').submit();
       }
    })