<?php

/**
 * @file
 * Post-update scripts for Backup & Migrate.
 */

/**
 * Implementations of hook_post_update_NAME().
 */

/**
 * Force the system to clear the caches.
 */
function backup_migrate_post_update_5001() {
  // Do nothing, just force the system to clear the caches.
}
