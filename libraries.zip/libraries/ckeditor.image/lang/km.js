/*
Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'image', 'km', {
	alt: 'អត្ថបទជំនួស',
	border: 'ស៊ុម',
	btnUpload: 'ផ្ញើ​ទៅ​ម៉ាស៊ីន​បម្រើ',
	button2Img: 'តើ​អ្នក​ចង់​ផ្លាស់​ប្ដូរ​ប៊ូតុង​រូបភាព​ដែល​បាន​ជ្រើស នៅ​លើ​រូបភាព​ធម្មតា​មួយ​មែនទេ?',
	hSpace: 'គម្លាត​ផ្ដេក',
	img2Button: 'តើ​អ្នក​ចង់​ផ្លាស់​ប្ដូរ​រូបភាព​ដែល​បាន​ជ្រើស នៅ​លើ​ប៊ូតុង​រូបភាព​មែនទេ?',
	infoTab: 'ពត៌មានអំពីរូបភាព',
	linkTab: 'តំណ',
	lockRatio: 'ចាក់​សោ​ផល​ធៀប',
	menu: 'លក្ខណៈ​រូបភាព',
	resetSize: 'កំណត់ទំហំឡើងវិញ',
	title: 'លក្ខណៈ​រូបភាព',
	titleButton: 'លក្ខណៈ​ប៊ូតុង​រូបភាព',
	upload: 'ផ្ទុកឡើង',
	urlMissing: 'ខ្វះ URL ប្រភព​រូប​ភាព។',
	vSpace: 'គម្លាត​បញ្ឈរ',
	validateBorder: 'ស៊ុម​ត្រូវ​តែ​ជា​លេខ។',
	validateHSpace: 'គម្លាត​ផ្ដេក​ត្រូវ​តែ​ជា​លេខ។',
	validateVSpace: 'គម្លាត​បញ្ឈរ​ត្រូវ​តែ​ជា​លេខ។'
} );
