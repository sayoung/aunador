/**
 * @license Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */

CKEDITOR.plugins.setLang( 'uploadwidget', 'eu', {
	abort: 'Karga erabiltzaileak bertan behera utzita.',
	doneOne: 'Fitxategia behar bezala kargatu da.',
	doneMany: 'Behar bezala kargatu dira %1 fitxategi.',
	uploadOne: 'Fitxategia kargatzen ({percentage}%)...',
	uploadMany: 'Fitxategiak kargatzen, {current} / {max} eginda ({percentage}%)...'
} );
