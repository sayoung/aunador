/* eslint-disable import/prefer-default-export */

export const setIsLoading = isLoading => ({
  type: 'SET_IS_LOADING',
  isLoading,
});
