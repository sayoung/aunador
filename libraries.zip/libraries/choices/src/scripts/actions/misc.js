export const clearAll = () => ({
  type: 'CLEAR_ALL',
});

export const resetTo = state => ({
  type: 'RESET_TO',
  state,
});
