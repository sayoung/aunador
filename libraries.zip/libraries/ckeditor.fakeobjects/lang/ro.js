/*
Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'fakeobjects', 'ro', {
	anchor: 'Inserează/Editează ancoră',
	flash: 'Element Flash',
	hiddenfield: 'Câmp ascuns (HiddenField)',
	iframe: 'Fereastră în fereastră (iframe)',
	unknown: 'Necunoscut'
} );
