/**
 * @file
 * Opens the print window.
 */

document.addEventListener('DOMContentLoaded', function () {
  "use strict";
  window.print();
});
