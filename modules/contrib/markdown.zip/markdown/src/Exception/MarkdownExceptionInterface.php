<?php

namespace Drupal\markdown\Exception;

/**
 * Provides an interface that can be used to target relevant exceptions.
 */
interface MarkdownExceptionInterface {
}
