<?php

namespace Drupal\markdown\Exception;

/**
 * Provides an interface that can be used to target relevant exceptions.
 *
 * @todo Move upstream to https://www.drupal.org/project/installable_plugins.
 */
interface InstallablePluginExceptionInterface {
}
