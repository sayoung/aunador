<?php

namespace Drupal\md_agenda\Plugin\Block;

use Drupal\Core\Block\BlockBase;

/**
 * Provides a 'AgendaHPBlock' block.
 *
 * @Block(
 *  id = "md_agenda_hp_block",
 *  admin_label = @Translation("Agenda HP Block"),
 * )
 */
class AgendaHPBlock extends BlockBase {

  /**
   * {@inheritdoc}
   */
  public function build() {
	$lang_code = \Drupal::languageManager()->getCurrentLanguage()->getId();
    $query = \Drupal::entityQuery('node');
    $query->condition('type', 'md_agenda');
    $query->condition('status', 1);
	$query->condition('langcode', $lang_code);
    $query->sort('created', 'desc');
    $query->range(0, 3);
    $nids = $query->execute();
    $nodes = entity_load_multiple('node', $nids);

   // print_r($nodes);exit;

    return array(
      '#theme' => 'theme_md_agenda_hp',
      '#nodes' => $nodes,
	  '#attached' => array(
                'library' => array(
                    'md_agenda/md-agenda-hp'
                )
            )
    );
  }

}
