<?php

namespace Drupal\dardev_appel_offre\Helper;
use Drupal\Core\Database\Database;

Class Helper{
    
  const SETTINGS = 'dardev_appel.settings';
  
  public static function checkEmail($email){
    $conn = Database::getConnection();
    $record = array();
    $query = $conn->select('dardev_appel_offre_emails', 'm')
        ->condition('email', $email)
        ->fields('m');
    return $query->execute()->fetchAssoc();
  }

  public static function listEmails($niid){
    $query = \Drupal::database()->select('dardev_appel_offre_emails', 'm');
    $query->condition('id_offre',$niid);
    $query->fields('m', ['id', 'email']);
    return $query->execute()->fetchAll();
  }

}
