<?php

namespace Drupal\dardev_table\Plugin\views\style;

use Drupal\Core\Form\FormStateInterface;
use Drupal\views\Plugin\views\style\StylePluginBase;

use Drupal\views\Plugin\views\style\Table;

/**
 * Style plugin to render each item as a row in a table.
 *
 * @ingroup views_style_plugins
 *
 * @ViewsStyle(
 *   id = "dardev_table",
 *   title = @Translation("Table Responsive dardev"),
 *   help = @Translation("Displays rows as a table with custom options."),
 *   theme = "dardev_table",
 *   theme_file = "/../dardev_table.theme.inc",
 *   display_types = {"normal"}
 * )
 */


class TableResponsive extends Table  {
    /**
     * {@inheritdoc}
     */
    protected function defineOptions() {
      $options = parent::defineOptions();
  
      // Add custom options here.
      $options['dardev_table_option'] = ['default' => 'default_value'];
  
      return $options;
    }
  
    /**
     * {@inheritdoc}
     */
    public function buildOptionsForm(&$form, FormStateInterface $form_state) {
      parent::buildOptionsForm($form, $form_state);
  
      // Add custom options form here.
      $form['dardev_table_option'] = [
        '#type' => 'textfield',
        '#title' => $this->t('Table Responsive dardev'),
        '#default_value' => $this->options['dardev_table_option'],
      ];
    }
  
    /**
     * {@inheritdoc}
     */
    public function render() {
      // Add custom render logic here.
      $build = parent::render();
  
      $build['dardev_table_output'] = [
        '#markup' => 'Custom output',
      ];
  
      return $build;
    }
  
  }