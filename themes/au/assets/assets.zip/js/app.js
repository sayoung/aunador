$(document).ready(function() {
    $('#mob-header .menu-icon').click(function() {
        $('#mob-header .side-bar').addClass('active');
        $('#mob-header .menu-icon').addClass('active');
        $('#wrapper').addClass('active');
    });
    $('#mob-header .side-bar .close').click(function() {
        $('#mob-header .side-bar').removeClass('active');
        $('#wrapper').removeClass('active');
        $('#mob-header .menu-icon').removeClass('active');
    });
});

function searchToggle(obj, evt){
    var container = $(obj).closest('.search-wrapper');
        if(!container.hasClass('active')){
            container.addClass('active');
            evt.preventDefault();
        }
        else if(container.hasClass('active') && $(obj).closest('.input-holder').length == 0){
            container.removeClass('active');
            // clear input
            container.find('.search-input').val('');
        }
}

$( ".detail-block .icon-box.fir" ).mouseover(function(){
    $(".detail-block .icon-box img.first").addClass("d-none");
    $(".detail-block .icon-box img.sec").removeClass("d-none");
});

$( ".detail-block .icon-box" ).mouseout(function(){
    $(".detail-block .icon-box img.sec").addClass("d-none");
    $(".detail-block .icon-box img.first").removeClass("d-none");
});



$( ".detail-block .icon-box.sec" ).mouseover(function(){
    $(".detail-block .icon-box img.tri").addClass("d-none");
    $(".detail-block .icon-box img.for").removeClass("d-none");
});
$( ".detail-block .icon-box.sec" ).mouseout(function(){
    $(".detail-block .icon-box img.for").addClass("d-none");
    $(".detail-block .icon-box img.tri").removeClass("d-none");
});

$( ".detail-block .icon-box.thi" ).mouseover(function(){
    $(".detail-block .icon-box img.fiv").addClass("d-none");
    $(".detail-block .icon-box img.six").removeClass("d-none");
});
$( ".detail-block .icon-box.thi" ).mouseout(function(){
    $(".detail-block .icon-box img.six").addClass("d-none");
    $(".detail-block .icon-box img.fiv").removeClass("d-none");
});

$( ".detail-block .icon-box.for" ).mouseover(function(){
    $(".detail-block .icon-box img.sev").addClass("d-none");
    $(".detail-block .icon-box img.eig").removeClass("d-none");
});
$( ".detail-block .icon-box.for" ).mouseout(function(){
    $(".detail-block .icon-box img.eig").addClass("d-none");
    $(".detail-block .icon-box img.sev").removeClass("d-none");
});

$( ".detail-block .icon-box.fiv" ).mouseover(function(){
    $(".detail-block .icon-box img.nin").addClass("d-none");
    $(".detail-block .icon-box img.ten").removeClass("d-none");
});
$( ".detail-block .icon-box.fiv" ).mouseout(function(){
    $(".detail-block .icon-box img.ten").addClass("d-none");
    $(".detail-block .icon-box img.nin").removeClass("d-none");
});

$( ".detail-block .icon-box.six" ).mouseover(function(){
    $(".detail-block .icon-box img.ele").addClass("d-none");
    $(".detail-block .icon-box img.tel").removeClass("d-none");
});
$( ".detail-block .icon-box.six" ).mouseout(function(){
    $(".detail-block .icon-box img.tel").addClass("d-none");
    $(".detail-block .icon-box img.ele").removeClass("d-none");
});